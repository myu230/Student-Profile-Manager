﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentProfileManagementApp
{
    public partial class StudentManagerForm : Form
    {
        private GradeDAO gdao;

        public StudentManagerForm()
        {
            InitializeComponent();
        }

        private void StudentManagerForm_Load(object sender, EventArgs e)
        {
            gdao = new GradeDAO();
            ClassMonitorForm frmcm;

            frmcm = new ClassMonitorForm(gdao);
            frmcm.Show(this);
        }

        private void txt_TextChanged(object sender, EventArgs e)
        {
            int studentNum;
            double grade;
            bool bStudentNum, bGrade;

            bStudentNum = int.TryParse(txtStudentNum.Text, out studentNum);
            bGrade = double.TryParse(txtGrade.Text, out grade);

            btnGetProfile.Enabled = btnDeleteProfile.Enabled = (bStudentNum && studentNum >= 10000000 && studentNum <= 99999999);
            btnUpdateProfile.Enabled = (bGrade && grade >= 0 && grade <= 100 && btnGetProfile.Enabled);
            btnClearProfile.Enabled = ((txtStudentNum.TextLength > 0) || (txtName.TextLength > 0) || (txtGrade.TextLength > 0));
        } 

        private void btnClearProfile_Click(object sender, EventArgs e)
        {
            txtStudentNum.Clear();
            txtName.Clear();
            txtGrade.Clear();
            txtStudentNum.Focus();
        }    
        
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGetProfile_Click(object sender, EventArgs e)
        {
            try
            {
                txtName.Text = gdao.GetName(Convert.ToInt32(txtStudentNum.Text));
                txtGrade.Text = Convert.ToString(gdao.GetGrade(Convert.ToInt32(txtStudentNum.Text)));
            }
            catch (ArgumentException erm)
            {
                MessageBox.Show(String.Format("{0}", erm.Message), "Student Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdateProfile_Click(object sender, EventArgs e)
        {
            int studentNum = Convert.ToInt32(txtStudentNum.Text);
            double grade = Convert.ToDouble(txtGrade.Text);

            gdao.SetStudentProfile(studentNum, txtName.Text, grade);
        }

        private void btnDeleteProfile_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, String.Format("Are you sure you want to delete student #{0}?", txtStudentNum.Text), "Delete Student Profile", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {
                gdao.DeleteStudentProfile(Convert.ToInt32(txtStudentNum.Text));
            }

            txtStudentNum.Clear();
            txtName.Clear();
            txtGrade.Clear();
            txtStudentNum.Focus();
        }
    }
}

