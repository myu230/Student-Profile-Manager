﻿namespace StudentProfileManagementApp
{
    partial class StudentManagerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGetProfile = new System.Windows.Forms.Button();
            this.btnUpdateProfile = new System.Windows.Forms.Button();
            this.btnDeleteProfile = new System.Windows.Forms.Button();
            this.btnClearProfile = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lbStudentNum = new System.Windows.Forms.Label();
            this.lbName = new System.Windows.Forms.Label();
            this.lbGrade = new System.Windows.Forms.Label();
            this.txtStudentNum = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtGrade = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnGetProfile
            // 
            this.btnGetProfile.Enabled = false;
            this.btnGetProfile.Location = new System.Drawing.Point(313, 32);
            this.btnGetProfile.Name = "btnGetProfile";
            this.btnGetProfile.Size = new System.Drawing.Size(146, 23);
            this.btnGetProfile.TabIndex = 6;
            this.btnGetProfile.Text = "Get Student &Profile";
            this.btnGetProfile.UseVisualStyleBackColor = true;
            this.btnGetProfile.Click += new System.EventHandler(this.btnGetProfile_Click);
            // 
            // btnUpdateProfile
            // 
            this.btnUpdateProfile.Enabled = false;
            this.btnUpdateProfile.Location = new System.Drawing.Point(313, 60);
            this.btnUpdateProfile.Name = "btnUpdateProfile";
            this.btnUpdateProfile.Size = new System.Drawing.Size(146, 23);
            this.btnUpdateProfile.TabIndex = 7;
            this.btnUpdateProfile.Text = "&Update Student Profile";
            this.btnUpdateProfile.UseVisualStyleBackColor = true;
            this.btnUpdateProfile.Click += new System.EventHandler(this.btnUpdateProfile_Click);
            // 
            // btnDeleteProfile
            // 
            this.btnDeleteProfile.Enabled = false;
            this.btnDeleteProfile.Location = new System.Drawing.Point(313, 88);
            this.btnDeleteProfile.Name = "btnDeleteProfile";
            this.btnDeleteProfile.Size = new System.Drawing.Size(146, 23);
            this.btnDeleteProfile.TabIndex = 8;
            this.btnDeleteProfile.Text = "&Delete Student Profile";
            this.btnDeleteProfile.UseVisualStyleBackColor = true;
            this.btnDeleteProfile.Click += new System.EventHandler(this.btnDeleteProfile_Click);
            // 
            // btnClearProfile
            // 
            this.btnClearProfile.Enabled = false;
            this.btnClearProfile.Location = new System.Drawing.Point(313, 116);
            this.btnClearProfile.Name = "btnClearProfile";
            this.btnClearProfile.Size = new System.Drawing.Size(146, 23);
            this.btnClearProfile.TabIndex = 9;
            this.btnClearProfile.Text = "&Clear Student Profile";
            this.btnClearProfile.UseVisualStyleBackColor = true;
            this.btnClearProfile.Click += new System.EventHandler(this.btnClearProfile_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(313, 144);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(146, 23);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lbStudentNum
            // 
            this.lbStudentNum.AutoSize = true;
            this.lbStudentNum.Location = new System.Drawing.Point(12, 13);
            this.lbStudentNum.Name = "lbStudentNum";
            this.lbStudentNum.Size = new System.Drawing.Size(84, 13);
            this.lbStudentNum.TabIndex = 0;
            this.lbStudentNum.Text = "&Student Number";
            // 
            // lbName
            // 
            this.lbName.AutoSize = true;
            this.lbName.Location = new System.Drawing.Point(12, 69);
            this.lbName.Name = "lbName";
            this.lbName.Size = new System.Drawing.Size(35, 13);
            this.lbName.TabIndex = 2;
            this.lbName.Text = "&Name";
            // 
            // lbGrade
            // 
            this.lbGrade.AutoSize = true;
            this.lbGrade.Location = new System.Drawing.Point(12, 122);
            this.lbGrade.Name = "lbGrade";
            this.lbGrade.Size = new System.Drawing.Size(36, 13);
            this.lbGrade.TabIndex = 4;
            this.lbGrade.Text = "&Grade";
            // 
            // txtStudentNum
            // 
            this.txtStudentNum.Location = new System.Drawing.Point(15, 35);
            this.txtStudentNum.MaxLength = 8;
            this.txtStudentNum.Name = "txtStudentNum";
            this.txtStudentNum.Size = new System.Drawing.Size(292, 20);
            this.txtStudentNum.TabIndex = 1;
            this.txtStudentNum.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(15, 85);
            this.txtName.MaxLength = 40;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(292, 20);
            this.txtName.TabIndex = 3;
            this.txtName.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // txtGrade
            // 
            this.txtGrade.Location = new System.Drawing.Point(15, 143);
            this.txtGrade.MaxLength = 5;
            this.txtGrade.Name = "txtGrade";
            this.txtGrade.Size = new System.Drawing.Size(292, 20);
            this.txtGrade.TabIndex = 5;
            this.txtGrade.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // StudentManagerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 180);
            this.Controls.Add(this.txtGrade);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.txtStudentNum);
            this.Controls.Add(this.lbGrade);
            this.Controls.Add(this.lbName);
            this.Controls.Add(this.lbStudentNum);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClearProfile);
            this.Controls.Add(this.btnDeleteProfile);
            this.Controls.Add(this.btnUpdateProfile);
            this.Controls.Add(this.btnGetProfile);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "StudentManagerForm";
            this.Text = "Student Manager";
            this.Load += new System.EventHandler(this.StudentManagerForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGetProfile;
        private System.Windows.Forms.Button btnUpdateProfile;
        private System.Windows.Forms.Button btnDeleteProfile;
        private System.Windows.Forms.Button btnClearProfile;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lbStudentNum;
        private System.Windows.Forms.Label lbName;
        private System.Windows.Forms.Label lbGrade;
        private System.Windows.Forms.TextBox txtStudentNum;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtGrade;
    }
}

